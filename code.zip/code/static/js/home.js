/*
 * JavaScript file for the application to demonstrate
 * using the API
 */


// Create the namespace instance
let ns = {};

// Create the model instance
ns.model = (function() {
    'use strict';

    let $event_pump = $('body');

    // Return the API
    return {
        'predict': function(lname) {
            let ajax_options = {
                type: 'POST',
                url: 'api/people/' + lname,
                accepts: 'application/json',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify({
                    'lname': lname
                })
            };
            $.ajax(ajax_options)
            .done(function(data) {
                $event_pump.trigger('model_predict_success', [data]); //data is return in the corresponding function in the people.py
            })
            .fail(function(xhr, textStatus, errorThrown) {
                $event_pump.trigger('model_error', [xhr, textStatus, errorThrown]);
            })
        },
        'read': function() {
            let ajax_options = {
                type: 'GET',
                url: 'api/people',
                accepts: 'application/json',
                dataType: 'json'
            };
            $.ajax(ajax_options)
            .done(function(data) {
                $event_pump.trigger('model_read_success', [data]);
            })
            .fail(function(xhr, textStatus, errorThrown) {
                $event_pump.trigger('model_error', [xhr, textStatus, errorThrown]);
            })
        },
        create: function(lname,share) {
            let ajax_options = {
                type: 'POST',
                url: 'api/people',
                accepts: 'application/json',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify({
                    'lname': lname, // remember add the comma after each line, other error happen and compiler won't give you message how to fix
                    'share': share,
                })
            };
            $.ajax(ajax_options)
            .done(function(data) {
                $event_pump.trigger('model_create_success', [data]);
            })
            .fail(function(xhr, textStatus, errorThrown) {
                $event_pump.trigger('model_error', [xhr, textStatus, errorThrown]);
            })
        },
        update: function(lname,share) {
            let ajax_options = {
                type: 'PUT',
                url: 'api/people/' + lname,
                accepts: 'application/json',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify({
                    'lname': lname,
                    'share': share,
                })
            };
            $.ajax(ajax_options)
            .done(function(data) {
                $event_pump.trigger('model_update_success', [data]);
            })
            .fail(function(xhr, textStatus, errorThrown) {
                $event_pump.trigger('model_error', [xhr, textStatus, errorThrown]);
            })
        },
        'delete': function(lname) {
            let ajax_options = {
                type: 'DELETE',
                url: 'api/people/' + lname,
                accepts: 'application/json',
                contentType: 'plain/text'
            };
            $.ajax(ajax_options)
            .done(function(data) {
                $event_pump.trigger('model_delete_success', [data]);
            })
            .fail(function(xhr, textStatus, errorThrown) {
                $event_pump.trigger('model_error', [xhr, textStatus, errorThrown]);
            })
        }
    };
}());

// Create the view instance
ns.view = (function() {
    'use strict';

    let $lname = $('#lname');

    // return the API
    return {
        reset: function() {
            $lname.val('');
            //$fname.val('').focus();
        },
        update_editor: function(lname) {
            $lname.val(lname);
            //$fname.val(fname).focus();
        },
        build_table: function(people) {
            var total_revenue = 0;
            let rows = ''

            // clear the table
            $('.people table > tbody').empty();

            // did we get a people array?
            if (people) {
                var total_revenue = 0;
                for (let i=0, l=people.length; i < l; i++) {
                    rows += `<tr><td class="lname">${people[i].lname}</td><td>${people[i].timestamp}</td><td>${people[i].purchase_price}</td><td>${people[i].share}</td><td>${people[i].current_price}</td><td>${people[i].profit}</td></tr>`;
                    total_revenue += people[i].profit;
                }
                rows += `<tr><td class="lname">Total revenue</td><td>${total_revenue}</td></tr>`
                $('table > tbody').append(rows);
            }
        },
        error: function(error_msg) {
            $('.error')
                .text(error_msg)
                .css('visibility', 'visible');
            setTimeout(function() {
                $('.error').css('visibility', 'hidden');
            }, 3000)
        },
        predict_stock: function(return_list) {    // return the output from the function in people.py to the front end
            document.getElementById("demo").innerHTML = "Current price of stock is: " + return_list[0];
            document.getElementById("demo1").innerHTML = "predicted price of stock tomorrow is: " + return_list[1];
        }
    };
}());

// Create the controller
ns.controller = (function(m, v) {
    'use strict';

    let model = m,
        view = v,
        $event_pump = $('body'),
        $lname = $('#lname'),
        $share = $('#share');

    // Get the data from the model after the controller is done initializing
    setTimeout(function() {
        model.read();
    }, 100)

    // Validate input
    function validate(lname) {
        return lname !== "";
    }

    // Create our event handlers
    $('#create').click(function(e) {
        let lname = $lname.val();
        let share = $share.val();

        e.preventDefault();

        if (validate(lname)) {
            model.create(lname,share)
        } else {
            alert('Problem with first or last name input');
        }
    });

    $('#update').click(function(e) {
        let lname = $lname.val();
        let share = $share.val();

        e.preventDefault();

        if (validate(lname)) {
            model.update(lname,share)
        } else {
            alert('Problem with first or last name input');
        }
        e.preventDefault();
    });

    $('#delete').click(function(e) {
        let lname = $lname.val();

        e.preventDefault();

        if (validate('placeholder', lname)) {
            model.delete(lname)
        } else {
            alert('Problem with first or last name input');
        }
        e.preventDefault();
    });

    $('#reset').click(function() {
        view.reset();
    })

    $('#predict').click(function(e) {
        e.preventDefault();
        let lname = $lname.val();
        model.predict(lname);

        /*
        controller should call the function at the model, 
        and if the function is 'GET', then no parameters needed to passed and the 
        data at "$event_pump.on('model_create_success', function(e, data)" will 
        be data returned in people.py, on the other hand, if the function is POST
        , then we need to pass data, and the passed parameters will be handled by
        function in model above. 

        The data "$event_pump.on('model_create_s
        uccess', function(e, data)" is the data returned in people.py
        */

        e.preventDefault();
    });

    $('table > tbody').on('dblclick', 'tr', function(e) {
        let $target = $(e.target),
            lname;

        fname = $target
            .parent()
            .find('td.fname')
            .text();

        lname = $target
            .parent()
            .find('td.lname')
            .text();

        view.update_editor(lname);
    });

    // Handle the model events
    $event_pump.on('model_read_success', function(e, data) {
        view.build_table(data);
        view.reset();
    });

    $event_pump.on('model_create_success', function(e, data) {
        model.read();
    });

    $event_pump.on('model_update_success', function(e, data) {
        model.read();
    });

    $event_pump.on('model_delete_success', function(e, data) {
        model.read();
    });

    $event_pump.on('model_predict_success', function(e, data) {
        view.predict_stock(data);
    });

    $event_pump.on('model_error', function(e, xhr, textStatus, errorThrown) {
        let error_msg = textStatus + ': ' + errorThrown + ' - ' + xhr.responseJSON.detail;
        view.error(error_msg);
        console.log(error_msg);
    })
}(ns.model, ns.view));
