"""
This is the people module and supports all the ReST actions for the
PEOPLE collection
"""

# System modules
from datetime import datetime

# 3rd party modules
from flask import make_response, abort

import stocker
import yfinance as yf

from config import db
from models import Person, people_schema, person_schema


def get_timestamp():
    return datetime.now().strftime(("%Y-%m-%d %H:%M:%S"))


# Data to serve with our API
PEOPLE = {
    "TSM": {
        "lname": "TSM",
        "timestamp": get_timestamp(),
        "purchase_price": 99,
        "share": 700,
        "current_price": 100,
        "profit": 0,
    },
    "AAPL": {
        "lname": "AAPL",
        "timestamp": get_timestamp(),
        "purchase_price": 79,
        "share": 600,
        "current_price": 100,
        "profit": 0,
    },
    "MSFT": {
        "lname": "MSFT",
        "timestamp": get_timestamp(),
        "purchase_price": 89,
        "share": 500,
        "current_price": 100,
        "profit": 0,
    },
}


def read_all():
    """
    This function responds to a request for /api/people
    with the complete lists of people
    :return:        json string of list of people
    """

    people = Person.query.all()
    return people_schema.dump(people)

def read_one(lname):
    """
    This function responds to a request for /api/people/{lname}
    with one matching person from people
    :param lname:   last name of person to find
    :return:        person matching last name
    """
    # Does the person exist in people?
    if lname in PEOPLE:
        person = PEOPLE.get(lname)

    # otherwise, nope, not found
    else:
        abort(
            404, "Person with last name {lname} not found".format(lname=lname)
        )

    return person


def create(person):
    """
    This function creates a new person in the people structure
    based on the passed in person data
    :param person:  person to create in people structure
    :return:        201 on success, 406 on person exists
    """
    lname = person.get("lname", None)
    share = person.get("share", None)

    stock_info = yf.Ticker(lname).info #TSLA, AMZN
    market_price = stock_info['regularMarketPrice']

    # Does the person exist already?
    if lname not in PEOPLE and lname is not None:
        new_object = {
            "lname": lname,
            "timestamp": get_timestamp(),
            "purchase_price": market_price,
            "share": share,
            "current_price": market_price,
            "profit": 0,
        }

        new_person = person_schema.load(new_object, session=db.session)
        db.session.add(new_person)
        db.session.commit()
        return person_schema.dump(new_person), 201

        return make_response(
            "{lname} successfully created".format(lname=lname), 201
        )

    # Otherwise, they exist, that's an error
    else:
        abort(
            406,
            "Person with last name {lname} already exists".format(lname=lname),
        )


def update(lname, person):  
    """
    parameters have to match the parameters declared in swagger.yml, and the first parameter of this function is the last parameter 
    inserted at the end of the url, and the rest of the parameters are the parameters written in swagger.yml. 
    if the url doesn't have parameter at the front, then the parameter just need to match the parameters written in swagger.yml.
    
    This function updates an existing person in the people structure
    :param lname:   last name of person to update in the people structure
    :param person:  person to update
    :return:        updated person structure
    """
    lname = person.get("lname", None)
    share = person.get("share", None)

    existing_person = Person.query.filter(Person.lname == lname).one_or_none()

    stock_info = yf.Ticker(lname).info #TSLA, AMZN
    current_price = stock_info['regularMarketPrice']
    profit = (current_price-float(existing_person.purchase_price))*float(share)

    if existing_person:
        existing_person.share = share
        existing_person.profit = profit
        existing_person.current_price = current_price
        db.session.merge(existing_person)
        db.session.commit()
        return person_schema.dump(existing_person), 201
    else:
        abort(404, f"Person with last name {lname} not found")



def delete(lname):
    """
    This function deletes a person from the people structure
    :param lname:   last name of person to delete
    :return:        200 on successful delete, 404 if not found
    """

    existing_person = Person.query.filter(Person.lname == lname).one_or_none()

    if existing_person:
        db.session.delete(existing_person)
        db.session.commit()
        return make_response(f"{lname} successfully deleted", 200)
    else:
        abort(404, f"Person with last name {lname} not found")
        

def predict(lname, person):  # since fname and lname is passed to this function, fname and lname will be emerged to the person object, and since 'lname' is second parameter, this function also needs to take second parameter called 'lname'
    lname = person.get("lname", None)
    print('stock name: ', lname);
    stock_info = yf.Ticker(lname).info #TSLA, AMZN
    market_price = stock_info['regularMarketPrice']
    previous_close_price = stock_info['regularMarketPreviousClose']
    predict_list = stocker.predict.tomorrow(lname)
    print("predict list is: ", predict_list)

    return_list = [market_price,predict_list[0]]
    return return_list